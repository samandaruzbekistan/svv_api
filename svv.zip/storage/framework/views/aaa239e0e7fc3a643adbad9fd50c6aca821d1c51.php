<?php $__env->startSection('section'); ?>
    <?php if((session()->has('backData'))): ?>
        <?php switch(session('backData')):
            case (1): ?>
                <div class="container-fluid pt-4 px-4" id="data">
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Muvaffaqiyatli!</strong> Ma'lumot yangilandi.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                </div>
                <?php break; ?>

            <?php case (4): ?>
                <div class="container-fluid pt-4 px-4" id="data">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>Xatolik!</strong> Joriy parol notogri kiritildi.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                </div>
                <?php break; ?>

            <?php default: ?>
                Default case...
        <?php endswitch; ?>
    <?php endif; ?>

    <!-- Blank Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-12 col-xl-6">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Admin parolni yangilash</h6>
                    <form action="<?php echo e(route('admin_update')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Joriy parol</label>
                            <input  required type="password" name="password" class="form-control" id="exampleInputPassword1">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Yangi parol</label>
                            <input required type="password" name="new_password" class="form-control" id="exampleInputPassword1">
                        </div>

                        <button type="submit" class="btn btn-primary">Yangilash</button>
                    </form>
                </div>
            </div>
    </div>
    <!-- Blank End -->






<?php $__env->stopSection(); ?>




<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\svv\resources\views/account.blade.php ENDPATH**/ ?>